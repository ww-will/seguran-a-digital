### Acesse o [Figma](https://www.figma.com/community/file/1281336077503271053/javascript-senhas-seguras-com-matematica-e-programacao) para ter acesso ao protótipo

![Alura Start-JavaScript_ senhas seguras com matemática e programação](https://github.com/marcelopaludetto/js-gerador-senha/assets/78444171/7881b887-3df8-4f9b-921e-371861f3ddb5)
